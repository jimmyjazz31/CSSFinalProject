package pennerj.project;

import java.util.Date;

class WithdrawalTransaction extends Account{

	public WithdrawalTransaction(Investor primaryOwner, String accountId, Date openDate) {
		super(primaryOwner, accountId, openDate);
		// TODO Auto-generated constructor stub
	}

	public int getTransactionAmount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setDescription(String string) {
		// TODO Auto-generated method stub
		
	}

	public Account getFromAccount() {
		// TODO Auto-generated method stub
		return null;
	}

	public void print(Account account) {
		// TODO Auto-generated method stub
		
	}

}
