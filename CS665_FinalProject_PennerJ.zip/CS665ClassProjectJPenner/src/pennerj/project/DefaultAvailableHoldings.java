package pennerj.project;

import java.util.List;


public class DefaultAvailableHoldings extends SatelliteInvestments{
    public List<String> getAvailableHoldings() {
        // Return the default list of holdings
        return List.of("CSL.AX", "COL.AX", "ANZ.AX", "WES.AX", "ROBO.ETF", "SEMI.ETF", "QPON.ETF");
    }
}

