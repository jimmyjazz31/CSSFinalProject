package pennerj.project;

class WaitList extends ClientManage{

	public WaitList(String name, String id, String risk, double investmentAmount, String dateStr) {
		super(name, id, risk, investmentAmount, dateStr);
		// TODO Auto-generated constructor stub
	}

	public void simulateInvestorStatusChange() {
       
        int previousStatus = InvestorStatus.Invested;  // Assume the investor was previously invested
        int currentStatus = InvestorStatus.OnWaitList;  // Assume the investor is now on the waitlist

        // Call the method to handle the status change
        StaffType staff = new StaffType("SomeName");
        staff.notifyInvestorsOnWaitlist(previousStatus, currentStatus);
    }

	public static void updateInvestorStatusAndNotify() {
		// TODO Auto-generated method stub
		
	}

	
}
