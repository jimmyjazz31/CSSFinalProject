package pennerj.project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class PossibleInvest {
	// This is the main runnable of the project
	public static void main(String[] args) {
		System.out.println("Welcome to a new revamped way to Invest...yes it's Possible!!");
		System.out.println("========================================");

		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter First Name (alphabet, max 15 characters): ");
		String firstName = scanner.nextLine();

		System.out.println("Enter Last Name (alphabet, max 15 characters): ");
		String lastName = scanner.nextLine();

		System.out.println("Enter Preferred Email Address (alphanumeric@alphacharacters.com or .com.au): ");
		String email = scanner.nextLine();

		System.out.println("Enter Initial Australian Dollar Investment Amount (between 1000 and 2000000): ");
		double initialInvestmentAmount = validateInitialInvestmentInput(scanner);

		System.out.print("Would you like to do your risk profile? (Y/N): ");
		String riskProfileInput = scanner.nextLine().toUpperCase();

		if (riskProfileInput.startsWith("Y")) {
			RiskProfile riskProfile = new RiskProfile(firstName, lastName, email, initialInvestmentAmount);
			riskProfile.startRiskProfile();
		} else {
			// Proceed with other parts of the program or exit
			System.out.println("Thank you for using our service!");
		}

		Portfolio portfolioApp = Portfolio.getPortfolioInstance();

		// Create staff members
		StaffType leadPortfolioManager = new StaffType("Lead Portfolio Manager");
		StaffType fullTimeAnalyst = new StaffType("Full-Time Analyst");
		StaffType partTimeAnalyst = new StaffType("Part-Time Analyst");

		// Perform responsibilities
		leadPortfolioManager.performResponsibilities(StaffType.LEAD_PORTFOLIO_MANAGER);
		fullTimeAnalyst.performResponsibilities(StaffType.FULL_TIME_ANALYST);
		partTimeAnalyst.performResponsibilities(StaffType.PART_TIME_ANALYST);

		// Get investment amount from the user (you can use Scanner)
		double investmentAmount = 122000.00; // Example investment amount

		// Advise the investor
		String[] investmentAdvice = InvestmentAmount.adviseInvestor(investmentAmount);
		String investorType = investmentAdvice[0];
		String staffMember = investmentAdvice[1];
		System.out.println("Based on your investment amount, you are advised as a: " + investorType);
		System.out.println("Please communicate with: " + staffMember);

		WaitList.updateInvestorStatusAndNotify();

		// Call the method to notify investors on the waitlist
		leadPortfolioManager.notifyInvestorsOnWaitlist(InvestorStatus.Invested, InvestorStatus.OnWaitList);

		// Create an instance of SatelliteInvestments
		SatelliteInvestments satelliteInvestments = new SatelliteInvestments();

		// Create a list to hold selected holdings
		List<AvailableHoldings> selectedHoldings = new ArrayList<>();

		// Call the method to allow investors to choose satellite holdings
		satelliteInvestments.chooseSatelliteHoldings(selectedHoldings, 2);

		// Print the selected holdings
		System.out.println("Selected satellite holdings:");
		for (AvailableHoldings holding : selectedHoldings) {
			System.out.println("- " + holding.getHolding());
		}
		scanner.close();
	}

	private static double validateInitialInvestmentInput(Scanner scanner) {
		double input;
		while (true) {
			try {
				input = Double.parseDouble(scanner.nextLine().trim());
				if (input >= 1000 && input <= 2000000) {
					return input;
				} else {
					System.out.println("Invalid input. Please enter an amount between 1000 and 2000000.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid numeric amount.");
			}
		}
	}

	private static Date getDate(String dateStr) {
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MMMM dd, yyyy");
			return formatter.parse(dateStr);
		} catch (ParseException e) {
			throw new RuntimeException("Invalid Date... " + e.getMessage());
		}
	}
}
