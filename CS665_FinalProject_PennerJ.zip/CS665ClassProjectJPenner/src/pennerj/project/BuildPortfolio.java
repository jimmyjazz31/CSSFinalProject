package pennerj.project;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BuildPortfolio extends SatelliteInvestments{
    // Define industry sectors
    public enum IndustrySector {
        GLOBAL_SHARES("Global Shares"),
        DOMESTIC_BONDS("Domestic Bonds"),
        DOMESTIC_PROPERTY_SECURITIES("Domestic Property Securities"),
        DOMESTIC_SMALL_COMPANIES("Domestic Small Companies"),
        MATERIALS("Materials"),
        FINANCIALS("Financials"),
        MEDICAL_HEALTH("Health Care"),
        CONSUMER_STAPLES("Consumer Staples"),
        BUILDING_CONSTRUCTION("Building/Construction"),
        TECHNOLOGY_IT("Technology & IT"),
        INTERNATIONAL_BONDS("International Bonds");

        private final String description;

        IndustrySector(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    // Define holdings within each sector
    private static final List<AvailableHoldings> GLOBAL_SHARES_HOLDINGS = SatelliteInvestments.GLOBAL_SHARES_HOLDINGS;
    private static final List<AvailableHoldings> DOMESTIC_BONDS_HOLDINGS = SatelliteInvestments.DOMESTIC_BONDS_HOLDINGS;
    private static final List<AvailableHoldings> DOMESTIC_PROPERTY_SECURITIES_HOLDINGS = SatelliteInvestments.DOMESTIC_PROPERTY_SECURITIES_HOLDINGS;
    private static final List<AvailableHoldings> DOMESTIC_SMALL_COMPANIES_HOLDINGS = SatelliteInvestments.DOMESTIC_SMALL_COMPANIES_HOLDINGS;
    private static final List<Object> MATERIALS_HOLDINGS = List.of(SatelliteInvestments.BHP_AX);
    private static final List<Object> FINANCIALS_HOLDINGS = List.of(SatelliteInvestments.CBA_AX, SatelliteInvestments.ANZ_AX);
    private static final List<Object> MEDICAL_HEALTH_HOLDINGS = List.of(SatelliteInvestments.CSL_AX);
    private static final List<Object> CONSUMER_STAPLES_HOLDINGS = List.of(SatelliteInvestments.COL_AX);
    private static final List<Object> BUILDING_CONSTRUCTION_HOLDINGS = List.of(SatelliteInvestments.CSR_AX);
    private static final List<AvailableHoldings> TECHNOLOGY_IT_HOLDINGS = SatelliteInvestments.TECHNOLOGY_IT_HOLDINGS;
    private static final List<AvailableHoldings> INTERNATIONAL_BONDS_HOLDINGS = SatelliteInvestments.INTERNATIONAL_BONDS_HOLDINGS;

    // Create a mapping from sector to its constituent holdings
    private static final List<List<AvailableHoldings>> SECTOR_HOLDINGS_MAP = new ArrayList<>();
    static {
        SECTOR_HOLDINGS_MAP.add(GLOBAL_SHARES_HOLDINGS);
        SECTOR_HOLDINGS_MAP.add(DOMESTIC_BONDS_HOLDINGS);
        SECTOR_HOLDINGS_MAP.add(DOMESTIC_PROPERTY_SECURITIES_HOLDINGS);
        SECTOR_HOLDINGS_MAP.add(DOMESTIC_SMALL_COMPANIES_HOLDINGS);
        //SECTOR_HOLDINGS_MAP.add(MATERIALS_HOLDINGS);
        //SECTOR_HOLDINGS_MAP.add(FINANCIALS_HOLDINGS);
        //SECTOR_HOLDINGS_MAP.add(MEDICAL_HEALTH_HOLDINGS);
        //SECTOR_HOLDINGS_MAP.add(CONSUMER_STAPLES_HOLDINGS);
        //SECTOR_HOLDINGS_MAP.add(BUILDING_CONSTRUCTION_HOLDINGS);
        SECTOR_HOLDINGS_MAP.add(TECHNOLOGY_IT_HOLDINGS);
        SECTOR_HOLDINGS_MAP.add(INTERNATIONAL_BONDS_HOLDINGS);
    }

    // Format holdings in HTML format recursively
    public static String formatHoldingsInHTML(List<AvailableHoldings> holdings) {
        StringBuilder htmlBuilder = new StringBuilder();
        htmlBuilder.append("<ul>");
        for (AvailableHoldings holding : holdings) {
            htmlBuilder.append("<li>").append(holding.getHolding()).append("</li>");
        }
        htmlBuilder.append("</ul>");
        return htmlBuilder.toString();
    }

    public static void main(String[] args) {
        // Example usage
        //IndustrySector sector = IndustrySector.GLOBAL_SHARES;
        for (IndustrySector sector : IndustrySector.values()) {
            System.out.println("Sector: " + sector.getDescription());
            System.out.println("Description (HTML format): " + getHTMLDescription(sector));
            System.out.println("Holdings (HTML format):");
            System.out.println(formatHoldingsInHTML(getHoldingsForSector(sector)));
            System.out.println();
        }
        
    }

    

    // Method to get the HTML description for a sector
    private static String getHTMLDescription(IndustrySector sector) {
        // Here you can provide HTML descriptions for each sector
        // For simplicity, let's return a placeholder description
        return "<p>This is a placeholder description for " + sector.getDescription() + " sector.</p>";
    }

    // Method to get the holdings for a sector
    private static List<AvailableHoldings> getHoldingsForSector(IndustrySector sector) {
        // Implement logic to retrieve holdings for each sector
        // For now, let's return an empty list
        return new ArrayList<>();
    }
}
