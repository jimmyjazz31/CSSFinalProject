package pennerj.project;


	import java.text.DateFormat;
	import java.util.List;
	import java.util.ArrayList;
	import java.util.Date;

	public class Investor {
		private final String name;
		private final String customerId;
		private final String riskProfile;
		private final Double investmentAmount;
		private final Date registrationDate;
		private final List<Account> accountList;

		public Investor(String name, String customerId, String riskProfile, Double investmentAmount, Date registrationDate) {
			this.name = name;
			this.customerId = customerId;
			this.riskProfile = riskProfile;
			this.investmentAmount = investmentAmount;
			this.registrationDate = registrationDate;
			this.accountList = new ArrayList<>();
		}

		public String getName() {
			return this.name;
		}

		public String getCustomerId() {
			return this.customerId;
		}

		public Date getRegistrationDate() {
			return this.registrationDate;
		}

		public void addAccount(Account account) {

			accountList.add(account);

		}

		public void printStatement(Date toDate) {

			System.out.println(
					"\nInvestment Portfolio Statement - since inception - " + this.getName() + " - " + DateFormat.getDateInstance().format(toDate));

			
			for (Account account : this.accountList) {
				account.printStatement(this);
			}

			System.out.println("\nEND ACCOUNT STATEMENT\n");
		}

		
		public String getRiskProfile() {
			return riskProfile;
		}

		public Double getInvestmentAmount() {
			return investmentAmount;
		}

	}


