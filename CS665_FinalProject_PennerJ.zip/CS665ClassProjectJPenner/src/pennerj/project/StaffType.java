package pennerj.project;



public class StaffType {
    // Define constants for staff types
    public static final int LEAD_PORTFOLIO_MANAGER = 1;
    public static final int FULL_TIME_ANALYST = 2;
    public static final int PART_TIME_ANALYST = 3;

    // Instance variables
    private String name;

    // Constructor
    public StaffType(String name) {
        this.name = name;
    }

    // Methods
    public void performResponsibilities(int staffType) {
        switch (staffType) {
            case LEAD_PORTFOLIO_MANAGER:
                rebalanceSummitPortfolio();
                notifyInvestorOnWaitingList();
                overseeAllPortfolios();
                break;
            case FULL_TIME_ANALYST:
                manageAndRebalancePortfolios();
                break;
            case PART_TIME_ANALYST:
                manageAndRebalanceExpeditionPortfolio();
                break;
            default:
                System.out.println("Invalid staff type.");
        }
    }

    // Lead Portfolio Manager responsibilities
    private void rebalanceSummitPortfolio() {
        // Implement logic for managing and rebalancing the Summit Portfolio
        System.out.println("Lead Portfolio Manager is managing and rebalancing the Summit Portfolio.\n");
    }
    
    private void overseeAllPortfolios() {
        // Implement logic for managing and rebalancing the Summit Portfolio
        System.out.println("Lead Portfolio Manager managing and responsible for all existing Portfolios.\n");
    }

    private void notifyInvestorOnWaitingList() {
        // Implement logic for notifying an investor on the waiting list
        System.out.println("Lead Portfolio Manager is notifying an investor on the waiting list.\n");
    }

    // Full-Time Analyst responsibilities
    private void manageAndRebalancePortfolios() {
        // Implement logic for managing and rebalancing all portfolios
        System.out.println("Full-Time Analyst is managing and rebalancing all portfolios.\n");
    }

    // Part-Time Analyst responsibilities
    private void manageAndRebalanceExpeditionPortfolio() {
        // Implement logic for managing and rebalancing the Expedition Portfolio
        System.out.println("Part-Time Analyst is managing and rebalancing the Expedition Portfolio.\n");
    }
    
 // Method to notify investors on the waitlist about an open investment spot
    public void notifyInvestorsOnWaitlist(int previousInvestorStatus, int currentInvestorStatus) {
        if (InvestorStatus.isOpenedUp(previousInvestorStatus, currentInvestorStatus)) {
            // Logic to notify investors on the waitlist
     System.out.println("An investment place has opened up, do you want to place your investments");
        }
    }

    // Getter and setter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
