package pennerj.project;

import java.util.Scanner;



public class RiskProfile extends EstablishInvestment {

    // Updated constructor to match the new EstablishInvestment constructor
    public RiskProfile(String firstName, String lastName, String email, double initialInvestmentAmount) {
        super(firstName, lastName, email, initialInvestmentAmount);
    }


    // Method to start risk profile questionnaire
    public void startRiskProfile() {
        System.out.println("Welcome to the Risk Profile Questionnaire!\n");
        System.out.println("Please answer the following questions:\n");

        // Ask first 5 questions and record the user's choice
        int totalPoints = 0;
        totalPoints += askQuestion("RP1: Imagine you're on a TV game show, and you can choose one of the following, which would you choose",
                "A: $500 in cash.", "B: 50% chance of winning $2,000.", "C: 25% chance of winning $5,000.", "D: 5% chance of winning $30,000\n");

        totalPoints += askQuestion("RP2: In general, how would your closest confidant describe you as a risk-taker",
                "A: Risk must be avoided at all costs.", "B: As long as I've done some inquiry, I'll take on a bit of risk",
                "C: Cautious.", "D: A real risk-taker\n");

        totalPoints += askQuestion("RP3: What is your age?", "A: 60, and above.", "B: 41 to 60", "C: 21 To 40 ", "D: Under 20 \n");

        totalPoints += askQuestion("RP4: How stable do you think your income is in the coming 3-5 years?",
                "A: Really unstable. ", "B: Somewhat unstable. ", "C: Somewhat stable. ", "D: Really stable. \n");

        totalPoints += askQuestion("RP5: How much of your take-home pay do you think you would be able to save in the coming year?",
                "A: Approx 10-15% ", "B: Approx 15-20% ", "C: Approx 20-25%", "D: Over 25%	\n");

        // Display result based on total points
        displayResult(totalPoints);

        // Notify the full-time analyst of risk profile amendment
        if (totalPoints != 0) {
            notifyFullTimeAnalyst();
        }
    }

    private void notifyFullTimeAnalyst() {
        System.out.println("A new investor has commenced Risk Profile");// TODO Auto-generated method stub
    }

    // Method to ask a multiple-choice question and return the points based on the user's choice
    private int askQuestion(String question, String optionA, String optionB, String optionC, String optionD) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(question);
        System.out.println(optionA);
        System.out.println(optionB);
        System.out.println(optionC);
        System.out.println(optionD);

        System.out.print("Enter your choice (A/B/C/D): ");
        String userChoice = scanner.nextLine().toUpperCase();

        // Assign points based on user's choice
        switch (userChoice) {
            case "A":
                return 1;
            case "B":
                return 2;
            case "C":
                return 3;
            case "D":
                return 4;
            default:
                System.out.println("Invalid choice. 0 points assigned.");
                return 0;
        }
    }

    // Method to display the risk profile result based on total points
    private void displayResult(int totalPoints) {
        System.out.println("RISK PROFILE = \n");

        if (totalPoints >= 5 && totalPoints <= 8) {
            System.out.println("Your risk profile is conservative.\n");
        } else if (totalPoints >= 9 && totalPoints <= 12) {
            System.out.println("Your risk profile is balanced.\n");
        } else if (totalPoints >= 13 && totalPoints <= 16) {
            System.out.println("Your risk profile is growth.\n");
        } else {
            System.out.println("Unable to determine risk profile.\n");
        }
    }
}
