package pennerj.project;

import java.util.Date;
import pennerj.project.enumTypes.PortfolioType;

public class Portfolio extends PossibleInvest{
    private static Portfolio portfolioInstance;
    private SatelliteInvestments satelliteInvestments;

    private Portfolio() {
        satelliteInvestments = new SatelliteInvestments();
    }

    public static Portfolio getPortfolioInstance() {
        if (portfolioInstance == null) {
            portfolioInstance = new Portfolio();
        }
        return portfolioInstance;
    }

    public void createInvestor(String name, String id, String risk, double investment, Date date, String analyst) {
        // Determine the investor's portfolio type based on investment amount or risk profile
        PortfolioType portfolioType = determinePortfolioType(investment, risk);

        // Create investor account based on portfolio type
        switch (portfolioType) {
            case Expedition:
                // Create Expedition portfolio account
                createExpeditionPortfolio();
                break;
            case Ascent:
                // Create Ascent portfolio account
                createAscentPortfolio();
                break;
            case Summit:
                // Create Summit portfolio account
                createSummitPortfolio();
                break;
        }

        // Print account creation details
        System.out.println(name + ", your account has been created with portfolio type: " + portfolioType + analyst);
    }

    // Method to determine the investor's portfolio type based on investment amount or risk profile
    private PortfolioType determinePortfolioType(double investment, String risk) {
        // Add logic here to determine portfolio type based on investment amount or risk profile
        // For now, let's assume it's based on investment amount
        if (investment < 50000.00) {
            return PortfolioType.Expedition;
        } else if (investment < 150000.00) {
            return PortfolioType.Ascent;
        } else {
            return PortfolioType.Summit;
        }
    }

    // Methods to create Expedition, Ascent, and Summit portfolios (with HTML output)
    private void createExpeditionPortfolio() {
        
    	String description = "Each of our portfolios are of a deep value philosophy. This one is offered to conservative, balanced and growth investors with $50,000 or under to invest.";
        String format = "A portfolio of 4 ETFs.";
        String analyst = "Your regular contact is our part-time analyst Georgia Jones";
        generateHTML("Expedition", description, format, analyst);
    }

    private void createAscentPortfolio() {
        String description = "Each of our portfolios are of a deep value philosophy. This one is offered in a range of risk from Balanced Growth to Growth, and have between $50,000 - $150,000 to invest.";
        String format = "A portfolio of 4 ETFs, some direct shares, and flexibility for investors to choose another 2 satellite investments for broader diversification.";
        String analyst = "Your regular contact is our full-time analyst Perry Smythe";
        generateHTML("Ascent", description, format, analyst);
    }

    private void createSummitPortfolio() {
        String description = "Each of our portfolios are of a deep value philosophy. This one is offered in a risk range from Conservative, to Balanced Growth to Growth, and have upwards of $150,000 to invest.";
        String format = "A portfolio of 5 ETFs, some direct shares, and flexibility for investors to choose another 5 satellite investments for broader diversification.";
        String analyst = "Your regular contact is our full-time analyst Noelle Cherry";
        generateHTML("Summit", description, format, analyst);
    }

    // Method to generate HTML output for each portfolio type
    private void generateHTML(String portfolioType, String description, String format, String analyst) {
        System.out.println("Portfolio Type: " + portfolioType);
        System.out.println("Description (HTML format): " + "<p>" + description + "</p>");
        System.out.println("Format (HTML format): " + "<p>" + format + "</p>");
    }
}