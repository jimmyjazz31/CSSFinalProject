package pennerj.project;

public class InvestorStatus {
	 public static final int Invested = 1;
	 public static final int OnWaitList = 2;
	 public static final int ClosedAccount = 3;


//Method to check if an investment spot has opened up
public static boolean isOpenedUp(int previousStatus, int currentStatus) {
    return previousStatus == Invested && currentStatus != Invested;
}
}