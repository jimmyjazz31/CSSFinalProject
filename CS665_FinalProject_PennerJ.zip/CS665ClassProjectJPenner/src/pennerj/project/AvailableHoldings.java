package pennerj.project;



public class AvailableHoldings extends DefaultAvailableHoldings{
    private String holding;

    public AvailableHoldings(String holding) {
        this.holding = holding;
    }

    public String getHolding() {
        return holding;
    }

    public void setHolding(String holding) {
        this.holding = holding;
    }
}
