package pennerj.project;

import java.util.Scanner;

public class EstablishInvestment {

	private String firstName;
	private String lastName;
	private String email;
	private double initialInvestmentAmount;

	// Constructor to initialize variables
	public EstablishInvestment(String firstName2, String lastName2, String email2, double initialInvestmentAmount2) {

	}

	public void collectUserInput() {
		Scanner scanner = new Scanner(System.in);

		// Collect user input for name
		collectNameInput(scanner);

		// Collect user input for email
		collectEmailInput(scanner);

		// Collect user input for initial investment amount
		collectInitialInvestmentInput(scanner);

		// Check if user wants to determine the Investment Risk Profile
		determineRiskProfile(scanner);

		// Close scanner
		scanner.close();
	}

	private void determineRiskProfile(Scanner scanner) {
		// TODO Auto-generated method stub
		
	}

	private void collectNameInput(Scanner scanner) {
		System.out.println("Enter First Name (alphabet, max 15 characters): ");
		setFirstName(validateAlphabeticInput(scanner, 15));

		System.out.println("Enter Last Name (alphabetic, max 15 characters): ");
		setLastName(validateAlphabeticInput(scanner, 15));
	}

	private String validateAlphabeticInput(Scanner scanner, int maxLength) {
		String input;
		while (true) {
			input = scanner.nextLine().trim();
			if (input.matches("[a-zA-Z]+") && input.length() <= maxLength) {
				return input;
			} else {
				System.out.println("Invalid input. Please enter alphabetic characters within the specified limit.");
			}
		}
	}

	private void collectEmailInput(Scanner scanner) {
		System.out.println("Enter Preferred Email Address (alphanumeric@alphacharacters.com or .com.au): ");
		setEmail(validateEmailInput(scanner));
	}

	private String validateEmailInput(Scanner scanner) {
		String input;
		while (true) {
			input = scanner.nextLine().trim();
			if (input.matches("[a-zA-Z0-9]+@[a-zA-Z]+(\\.com\\.au|\\.com)")) {
				return input;
			} else {
				System.out.println("Invalid input. Please enter a valid email address.");
			}
		}
	}

	private void collectInitialInvestmentInput(Scanner scanner) {
		System.out.println("Enter Initial Australian Dollar Investment Amount (between 1000 and 2000000): ");
		setInitialInvestmentAmount(validateInitialInvestmentInput(scanner));
	}

	private double validateInitialInvestmentInput(Scanner scanner) {
		double input;
		while (true) {
			try {
				input = Double.parseDouble(scanner.nextLine().trim());
				if (input >= 1000 && input <= 2000000) {
					return input;
				} else {
					System.out.println("Invalid input. Please enter an amount between 1000 and 2000000.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid numeric amount.");
			}
		}
	}

	// Helper method to determine risk profile status
	@SuppressWarnings("unused")
	private String riskProfile() {
		// Implement logic to determine risk profile status (e.g., based on user input)
		// For now, return a placeholder value
		return "Not Started";
	}

	private void VInvestment(Scanner scanner) {
		// Example usage of handling risk profile input
		System.out.print("Would you like to do your risk profile? (Y/N): ");
		String riskProfileInput = scanner.nextLine().toUpperCase();
		boolean doRiskProfile = riskProfileInput.startsWith("Y");
		System.out.println("Do risk profile: " + doRiskProfile);
		{
			System.out.println("Note: You may need 4-5 minutes to complete this 10 question process.");
			// Call the method to start the RiskProfile questionnaire (not implemented here)
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void getEmail() {
		try {
			return;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getInitialInvestmentAmount() {
		return initialInvestmentAmount;
	}

	public void setInitialInvestmentAmount(double initialInvestmentAmount) {
		this.initialInvestmentAmount = initialInvestmentAmount;
	}

	public void collectUserInput(Scanner scanner) {
		// TODO Auto-generated method stub

	}

}
