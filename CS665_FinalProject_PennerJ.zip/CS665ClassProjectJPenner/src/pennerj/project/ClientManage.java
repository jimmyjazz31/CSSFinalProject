package pennerj.project;

public class ClientManage {

	
		    private String name;
			private String id;
			private String risk;
			private double investmentAmount;
			private String dateStr;

			public ClientManage(String name, String id, String risk, double investmentAmount, String dateStr) {
		        this.name = name;
		        this.id = id;
		        this.risk = risk;
		        this.investmentAmount = investmentAmount;
		        this.dateStr = dateStr;
		    }

		    public String getName() {
		        return name;
		    }

		    public String getId() {
		        return id;
		    }

		    public String getRisk() {
		        return risk;
		    }

		    public double getInvestmentAmount() {
		        return investmentAmount;
		    }

		    public String getDateStr() {
		        return dateStr;
		    }
		
	}


