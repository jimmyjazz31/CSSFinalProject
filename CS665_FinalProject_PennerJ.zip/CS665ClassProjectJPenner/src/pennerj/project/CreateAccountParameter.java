package pennerj.project;

import java.util.Date;


import pennerj.project.enumTypes.PortfolioType;

public class CreateAccountParameter extends PossibleInvest{
	public String customerId;
	public PortfolioType portfolioType;
	public String accountId;
	public Date openDate;
	public Double initialAmount;

	public CreateAccountParameter(String customerId, PortfolioType portfolioType, String accountId, Date openDate,
			Double initialAmount) {
		this.customerId = customerId;
		this.portfolioType = portfolioType;
		this.accountId = accountId;
		this.openDate = openDate;
		this.initialAmount = initialAmount;
	}
}

