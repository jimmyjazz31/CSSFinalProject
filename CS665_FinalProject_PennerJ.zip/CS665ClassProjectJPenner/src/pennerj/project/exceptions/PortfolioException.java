package pennerj.project.exceptions;

public class PortfolioException extends RuntimeException {
	    private static final long serialVersionUID = 1L;

		public PortfolioException(String msg) {
	        super(msg);
	    }
	}

