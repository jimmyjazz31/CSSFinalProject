package pennerj.project;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pennerj.project.Investor;
import pennerj.project.enumTypes.PortfolioStatus;
import pennerj.project.WithdrawalTransaction;
import pennerj.project.enumTypes.PortfolioStatus;
import pennerj.project.exceptions.PortfolioException;


public abstract class Account {

	 private final String accountId;
	    private final Date openDate;
	    private Date closeDate;

	    private final Investor primaryOwner;
	    

	    private PortfolioStatus portStatus;

	    private int currentBalance;

	    private final List<Transaction> transactionList;

	    public Account(Investor primaryOwner, String accountId, Date openDate) {
	        this.accountId = accountId;
	        this.openDate = openDate;
	        this.portStatus = portStatus.Open;
	        this.currentBalance = 0;
	        this.transactionList = new ArrayList<>();
	        this.primaryOwner = primaryOwner;
	        primaryOwner.addAccount(this);
	    }

	    public Investor getPrimaryOwner() {
	        return this.primaryOwner;
	    }

	    public String getAccountId() {
	        return this.accountId;
	    }

	    public Date getOpenDate() {
	        return this.openDate;
	    }

	    public PortfolioStatus getAccountStatus() {
	        return this.portStatus;
	    }

	    public int getCurrentBalance() {
	        return this.currentBalance;
	    }

	    
	    protected synchronized void addTransaction(Transaction t) {
	        if (this.portStatus == PortfolioStatus.Close)
	            throw new PortfolioException("Account " + this.getAccountId() + " closed... Transaction not allowed");

	        
	            Transaction withdrawal = (Transaction) t;
	            if (withdrawal.getTransactionAmount() <= getCurrentBalance()) {
	                withdraw(withdrawal.getTransactionAmount());
	                // Add the hard-coded statement for withdrawal
	                System.out.println("Now that we have had a withdrawal from our portfolios, the Lead Portfolio Manager will notify the first investor on the wait list.");
	            } else {
	                System.out.println("Warning: Insufficient funds for withdrawal from account " + this.getAccountId());
	            }
	           
	            this.transactionList.add(withdrawal);
	        }
	    

	    private synchronized void withdraw(int amount) {
	        if (amount <= this.currentBalance) {
	            this.currentBalance -= amount;
	        } else {
	            // Handle insufficient funds if necessary
	        }
	    }

	    public synchronized void closeAccount(Date closeDate) {
	        this.portStatus = PortfolioStatus.Close;
	        this.setCloseDate(closeDate);
	    }

	    public Date getCloseDate() {
	        return closeDate;
	    }

	    public void setCloseDate(Date closeDate) {
	        this.closeDate = closeDate;
	    }
	}
