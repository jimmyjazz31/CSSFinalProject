package pennerj.project;

import java.util.ArrayList;
import java.util.List;

public class SatelliteInvestments {

    // Define available satellite holdings
    public static final List<AvailableHoldings> GLOBAL_SHARES_HOLDINGS = new ArrayList<>();
    public static final List<AvailableHoldings> DOMESTIC_BONDS_HOLDINGS = new ArrayList<>();
    public static final List<AvailableHoldings> DOMESTIC_PROPERTY_SECURITIES_HOLDINGS = new ArrayList<>();
    public static final List<AvailableHoldings> DOMESTIC_SMALL_COMPANIES_HOLDINGS = new ArrayList<>();
    public static final List<AvailableHoldings> TECHNOLOGY_IT_HOLDINGS = new ArrayList<>();
    public static final List<AvailableHoldings> INTERNATIONAL_BONDS_HOLDINGS = new ArrayList<>();

    // Define available individual stocks and ETFs
    public static final AvailableHoldings QUAL_ETF = new AvailableHoldings("QUAL.ETF");
    public static final AvailableHoldings ILB_ETF = new AvailableHoldings("ILB.ETF");
    public static final AvailableHoldings MVA_ETF = new AvailableHoldings("MVA.ETF");
    public static final AvailableHoldings EX20_ETF = new AvailableHoldings("EX20.ETF");
    public static final AvailableHoldings BHP_AX = new AvailableHoldings("BHP.AX");
    public static final AvailableHoldings CBA_AX = new AvailableHoldings("CBA.AX");
    public static final AvailableHoldings ANZ_AX = new AvailableHoldings("ANZ.AX");
    public static final AvailableHoldings CSR_AX = new AvailableHoldings("CSR.AX");
    public static final AvailableHoldings CSL_AX = new AvailableHoldings("CSL.AX");
    public static final AvailableHoldings COL_AX = new AvailableHoldings("COL.AX");
    public static final AvailableHoldings ROBO_ETF = new AvailableHoldings("ROBO.ETF");
    public static final AvailableHoldings SEMI_ETF = new AvailableHoldings("SEMI.ETF");
    public static final AvailableHoldings QPON_ETF = new AvailableHoldings("QPON.ETF");

    static {
        // Populate lists with available holdings
        GLOBAL_SHARES_HOLDINGS.add(QUAL_ETF);
        DOMESTIC_BONDS_HOLDINGS.add(ILB_ETF);
        DOMESTIC_PROPERTY_SECURITIES_HOLDINGS.add(MVA_ETF);
        DOMESTIC_SMALL_COMPANIES_HOLDINGS.add(EX20_ETF);
        TECHNOLOGY_IT_HOLDINGS.add(ROBO_ETF);
        TECHNOLOGY_IT_HOLDINGS.add(SEMI_ETF);
        INTERNATIONAL_BONDS_HOLDINGS.add(QPON_ETF);
    }


	// Method to allow investors to choose satellite holdings
	public void chooseSatelliteHoldings(List<AvailableHoldings> selectedHoldings, int maxSelections) {
		System.out.println("Please select " + maxSelections + " satellite holdings from the following list:");
		for (int i = 0; i < availableHoldings.size(); i++) {
			System.out.println((i + 1) + ". " + availableHoldings.get(i));
		}

		String[] selectedHoldings;
		// Assume that the investor makes their selections somehow and adds them to the
		// selectedHoldings list
		// Here, we can just hardcode some selections for testing purposes
		selectedHoldings.add("CSL.AX");
		selectedHoldings.add("COL.AX");

		// Print the selected holdings
		System.out.println("Selected satellite holdings:");
		for (String holding : selectedHoldings) {
			System.out.println("- " + holding);
		}
	}

}
