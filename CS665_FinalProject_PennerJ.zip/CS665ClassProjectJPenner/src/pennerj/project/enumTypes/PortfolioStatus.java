package pennerj.project.enumTypes;

public enum PortfolioStatus {
	Open,
    Close
}
