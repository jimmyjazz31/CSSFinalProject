package pennerj.project.enumTypes;

public enum PortfolioType {

	Expedition,
	Ascent,
	Summit

}
