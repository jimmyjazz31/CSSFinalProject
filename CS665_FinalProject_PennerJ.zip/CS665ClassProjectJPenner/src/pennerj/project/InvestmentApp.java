package pennerj.project;



	import java.util.Date;
	import pennerj.project.Portfolio;

	public class InvestmentApp {
	    public static void main(String[] args) {
	        // Example usage: calling createInvestor method
	        String name = "John Doe";
	        String id = "123456789";
	        String risk = "Balanced Growth";
	        double investment = 170000.0; // Example investment amount
	        Date date = new Date(); // Example date
	        String analyst = " and your Full-Time analyst is Noelle Smythe";

	        // Instantiate Portfolio class and call createInvestor method
	        Portfolio portfolio = Portfolio.getPortfolioInstance();
	        portfolio.createInvestor(name, id, risk, investment, date, analyst);
	    }
	}

