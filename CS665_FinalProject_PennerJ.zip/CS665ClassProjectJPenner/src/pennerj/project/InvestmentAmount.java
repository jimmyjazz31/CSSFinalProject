package pennerj.project;

public class InvestmentAmount extends InvestmentApp{
	
    public static String[] adviseInvestor(double investmentAmount) {
        String investorType;
        String staffMember;
        
        if (investmentAmount < 50000) {
            investorType = "Expedition Investor";
            staffMember = "Part-Time Analyst";
        } else if (investmentAmount >= 50000 && investmentAmount <= 150000) {
            investorType = "Ascent Investor";
            staffMember = "Full-Time Analyst";
        } else {
            investorType = "Summit Investor";
            staffMember = "Full-Time Analyst or Lead Portfolio Manager";
        }
        
        return new String[]{investorType, staffMember};
    }
}

